import sys
sys.stdin = open('4828.txt','r')


def max_or_min(A):
    return max(A) - min(A)


T = int(input())
for tc in range(1, T+1):
    N = int(input())
    H = list(map(int,input().split()))

    num = max_or_min(H)
    print('#%d %d' %(tc, num))